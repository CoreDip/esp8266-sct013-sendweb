<?php
$mysqli = new mysqli('localhost', 'root', 'root', '8266');
$result = $mysqli->query('SELECT current, datetime , active FROM statistic WHERE record=(SELECT max(record) FROM statistic);');

while(($row = $result->fetch_assoc()) !== null){
  $datetime=$row['datetime']; //2021-04-20 09:35:45
  $current=$row['current'];
  $active=$row['active'];
}

$year=$datetime[0].$datetime[1].$datetime[2].$datetime[3];
$month=$datetime[5].$datetime[6];
$day=$datetime[8].$datetime[9];
$time=$datetime[11].$datetime[12].$datetime[13].$datetime[14].$datetime[15].$datetime[16].$datetime[17].$datetime[18];
?>
