<?php
$mysqli = new mysqli('localhost', 'root', 'root', '8266');

$mysqli->query(
  "CREATE TABLE IF NOT EXISTS statistic (
  `record` INT(20) NOT NULL AUTO_INCREMENT,
  `datetime` VARCHAR(30),
  `voltage` FLOAT(4),
  `current` FLOAT(4),
  `active` FLOAT(4),
  `energy` FLOAT(4),
  PRIMARY KEY(`record`));"
);

if($_GET['I']){
  if($_GET['key']==712){
    $current=round($_GET['I'], 4);
    $active=220*$current;
    $mysqli->query(
      "INSERT INTO statistic VALUES (
      NULL,
      '".date('Y-m-d H:i:s')."',
      220,
      '".$current."',
      '".$active."',
      46);"
    );
    echo "Дані записано";
  }
  else{echo "Ключ не вірний";}
}

if($_GET['Wh']){
  $Wh=round($_GET['Wh'], 4);
  $mysqli->query(
    "CREATE TABLE IF NOT EXISTS Wh (
    `id` INT(5) NOT NULL AUTO_INCREMENT,
    `Wh` FLOAT(9),
    PRIMARY KEY(`id`));"
  );
  $result=mysqli_query($mysqli, "SELECT * FROM Wh");
  $num=mysqli_num_rows($result);
  if($num<1){$mysqli->query("INSERT INTO Wh VALUES (1,0);");}
  $mysqli->query("UPDATE Wh SET Wh=Wh+'".$Wh."';");
}
?>
