<?php
$login = "admin";
$password = "1234";
if (!isset($_SERVER['PHP_AUTH_USER'])) {
    header("WWW-Authenticate: Basic realm=\"Вхід в Адмін Панель");
    header("HTTP/1.0 401 Unauthorized");
    die ("Доступ тільки для администраторів!\n");
    exit;
  }
if($_SERVER['PHP_AUTH_USER'] != $login and $_SERVER['PHP_AUTH_PW']!= $password)
   {
   header("WWW-Authenticate: Basic realm=\"Вхід в Адмін Панель");
    header("HTTP/1.0 401 Unauthorized");
    die ("Доступ тільки для администраторів!\n");
   }
?>


<html>
<head>
  <title>Esp8266 Адміністрування</title>
  <?php
  require 'Wh.php';
  require 'statistic.php';
  function delete(){
    $mysqli = new mysqli('localhost', 'root', 'root', '8266');
    echo "<script>alert('Всі данні очищено!'); self.location='index.php';</script>";
    $mysqli->query('DROP TABLE IF EXISTS wh;');
    $mysqli->query('DROP TABLE IF EXISTS statistic;');
  }
  if(array_key_exists('delete',$_POST)){
    delete();
  }
  ?>
  <style>
  .statisticwh{
    padding: 1%;
    padding-left: 1%;
    background-color: #80FD7A;
    width: 101%;
    margin-left: -1%;
  }
  .stats{
    font-size: 12pt;
    color: #2652C1;
    font-family: FreeMono, monospace;
    font-weight: bold;

  }
  .header{
    color: #3CE559;
    font-family: FreeMono, monospace;
    font-weight: bold;
    color: white;
    font-size: 18pt;
    text-align: center;
    margin: 1%;
    text-shadow: #43FE24 0 0 5px;
  }
  .delete{
      color: white;
      background-color: #C03642;
      border: 2px solid #F6300E;
      border-radius: 5px;
      box-shadow: #F6300E 0 0 8px;
      font-size: 14pt;
      padding: 0.5%;
      margin: 0.5%;
    }

    .c8266{
      color: white;
      background-color: #3CE559;
      border: 2px solid #17FF00;
      border-radius: 5px;
      box-shadow: #58FF00 0 0 8px;
      font-size: 14pt;
      padding: 0.5%;
      margin: 0.5%;
    }
    .c8266:hover {
      color: #0F9002; /* Цвет ссылки при наведении на нее курсора мыши */
      text-decoration: underline; /* Добавляем подчеркивание */
     }

     .delete:hover {
       color: #FF0000; /* Цвет ссылки при наведении на нее курсора мыши */
       text-decoration: underline; /* Добавляем подчеркивание */
      }

     .buttons{
       font-size: 12pt;
       color: #2652C1;
       font-family: FreeMono, monospace;
       font-weight: bold;
       display: inline;
     }

  </style>
</head>
<body bgcolor="#2a2a2b">
 <div class='header'>Адміністрування</div>
<div class='statisticwh'>
  <div class='stats'>Всього спожито:  <?php echo $Wh;?> Вт/год </div>
  <div class='stats'>Остання відправка:   <?php echo $day.".".$month.".".$year." ".$time;?></div>
  <div class='stats'>Останнє значення струму:   <?php echo $current;?> А</div>
    <div class='stats'>Остання потужність:   <?php echo $active;?> Вт</div>
</div><br>

  <form method="post">
    <center>
      <div class='buttons'><a class='c8266' href="http://8266.monitoring-esp.ml/" class="button">Назад</a></div>
      <div class='buttons'><input align='center' type="submit" name="delete" class="delete" value="Очистити статистику" /></div>
    </center>
  </form>

  <div style="text-align: center;" class='statisticwh'>
Copyright© by Dipcore 2021
  </div>

</body>
</html>
</html>
